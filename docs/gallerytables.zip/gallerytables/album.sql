CREATE TABLE `album` (
`album_id` INT( 11 ) NOT NULL AUTO_INCREMENT PRIMARY KEY ,
`user_id` INT( 11 ) NULL ,
`album` TEXT NOT NULL
) ENGINE = MYISAM ;
