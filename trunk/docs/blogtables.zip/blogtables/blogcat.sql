CREATE TABLE `blog_category` (
`category_id` INT( 10 ) NOT NULL AUTO_INCREMENT PRIMARY KEY ,
`category` TEXT NULL
) ENGINE = MYISAM ;